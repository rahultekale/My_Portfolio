import React, { Component } from 'react';
import './Home.css'; // Importing the CSS file
import profilePhoto from './Assets/photo.jpg'; // Correct way to import image

export class Home extends Component {
  render() {
    return (
      <div className='mainhome'>
        <h1 className='title1'>I'm a Java <br/> Full Stack Web Developer.</h1>
        <div className="container">
          {/* Left side: Image */}
          <div className="photo-section">
            <img src={profilePhoto} alt="Rahul Tekale" className="profile-photo" /> {/* Use imported image */}
          </div>

          {/* Right side: Profession description */}
          <div className="profession-section">
            <h2>Rahul RadhaKishan Tekale</h2>
            <h2>Computer Enginnering (BE-4th Year) AT <a href='https://www.mmit.edu.in/' >MMIT Pune</a></h2>
            <p>I am a Java Full Stack Web Developer with experience in creating web applications using React, Node.js, and Spring Boot.</p>
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
