import React from 'react';
import './Footer.css'; // Separate CSS for footer styling
import Instagram from './Assets/instagram.jpg'
import Youtube from './Assets/Youtube.png'
import Linkdin from './Assets/Linkdin.png'
import Github from './Assets/Github.png'
const Footer = () => {
  return (
    <footer className="footer">
      <div className="contact-section">
        <h2>Contact Me</h2>
        <p>Phone: +91 9579425910</p>
        <p>Email: rahultekale62@gmail.com</p>
      </div>
      
      <div className="social-section">
        <h2>Follow Me</h2>
        <a href="https://www.instagram.com/rahul_tekale_patil?igsh=MTV0M3d6ajBxdDU0YQ==" target="_blank" rel="noopener noreferrer">
          <img src={Instagram} alt="Instagram" className="social-icon" />
        </a>
        <a href="https://youtube.com/@codingjava1234?si=QtGAGTuDv5NDRvCB" target="_blank" rel="noopener noreferrer">
          <img src={Youtube} alt="YouTube" className="social-icon" />
        </a>
        <a href="https://github.com/rahultekale" target="_blank" rel="noopener noreferrer">
          <img src={Github} alt="GitHub" className="social-icon" />
        </a>
       
      </div>
    </footer>
  );
};

export default Footer;
