// src/components/Projects.js
import React from 'react';
import './Projects.css';
import ticTacToeImage from './Assets/tik-tak-toe-game.png'; // Ensure this matches your actual file name
import travellingWebsiteImage from './Assets/Travelling-image.jpg'; // Ensure this matches your actual file name
import remitoutCloneImage from './Assets/remitout-clone.jpg'; // Ensure this matches your actual file name
import Calculator from './Assets/Calculator.jpg'


const Projects = () => {
  return (
    <section className="projects-section">
      <h2>My Projects</h2>
      <div className="project-list" >
        <div className="project-item">
          <a href='https://github.com/rahultekale/travelling-Website'>
          <img src={travellingWebsiteImage} alt="Travelling Website" /></a>
          <h3>Travelling Website</h3>
          
          <p>A fully responsive website for planning trips and exploring destinations that are not to much fameus.</p>
        </div>
        
        <div className="project-item">
          <a href='https://github.com/rahultekale/Tic_Tak-Toe-Game'>
          <img src={ticTacToeImage} alt="Tic Tac Toe Game" /></a>
          <h3>Tic-Tac-Toe Game</h3>
          <p>A fun two-player game built with JavaScipt & Bootstrap.</p>
          
        </div>

        <div className="project-item">
          <a href='https://github.com/rahultekale/Remitout-Clone-web'>
          <img src={remitoutCloneImage} alt="Remitout Web Clone" /></a>
          <h3>Remitout Web Clone</h3>
          
          <p>A clone of the Remitout website, designed for money transfers and remittances.</p>
          
        </div>
        <div className="project-item">
          <a href='https://github.com/rahultekale/Calculator'>
          <img src={Calculator} alt="Tic Tac Toe Game" /></a>
          <h3>Web Calculator</h3>
          <p>A Simple Calculator build using javascript and Html,css,etc.</p>
          
        </div>
      </div>
    </section>
  );
};

export default Projects;
