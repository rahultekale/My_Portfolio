// src/components/Header.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css'; // Importing the CSS file
import './Header.css'; // Instead of Home.css

function Header() {
  return (
    <header>
      <ul className='nav-list'>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/projects">Projects</Link></li>
        <li><Link to="/experience">Experience</Link></li>
        <li><Link to="/book">Book a Call</Link></li>
      </ul>
    </header>
  );
}

export default Header;
