import React from 'react';
import './About.css';
import profileImage from './Assets/backg.png'; // Ensure you have a profile image in src/assets

const About = () => {
  return (
    <section className="about-section">
      <h2>About Me</h2>
      <div className="about-content">
        <img src={profileImage} alt="Profile" className="profile-image" />
        <div className="text-content">
          <p>Highest Education: BE - Computer Engineering</p>
          <p>Skills : Java, C++, Python, HTML, CSS, Bootstrap, JavaScript, React, Django, PHP, etc.</p>
          <p>Address : At Shubham Society, Viman nagar ,Pune - 411014 </p>
          <p>Experiance: 0-1 Year</p>
        </div>
      </div>
      
      <p>
        I am a Java Full Stack Web Developer with a passion for building dynamic and responsive web applications.
        My journey in tech started with a keen interest in coding, and it has evolved into a commitment to learning and creating innovative solutions.
        I enjoy working with modern technologies and collaborating with others to bring ideas to life.
      </p>

      {/* Education Table */}
      <h3>Education History</h3>
      <table className="education-table">
        <thead>
          <tr>
            <th>Standard</th>
            <th>Percentage/CGPA</th>
            <th>College Name</th>
            <th>Year of Completion</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>BE (Fourth Year)</td>
            <td>Not get</td>
            <td>Marathwada Mitra Mandal's Institute of technology, Lohegoan Pune</td>
            <td>2025</td>
          </tr>
          <tr>
            <td>BE (Third Year)</td>
            <td>9.29 CGPA</td>
            <td>Marathwada Mitra Mandal's Institute of technology, Lohegoan Pune</td>
            <td>2024</td>
          </tr>
          <tr>
            <td>BE (Second Year)</td>
            <td>8.01 CGPA</td>
            <td>Marathwada Mitra Mandal's Institute of technology, Lohegoan Pune</td>
            <td>2023</td>
          </tr>
          <tr>
            <td>BE (First Year) </td>
            <td>8.32 CGPA</td>
            <td>Marathwada Mitra Mandal's Institute of technology, Lohegoan Pune</td>
            <td>2022</td>
          </tr>
          <tr>
            <td>HSC - (Genearal Sceince)</td>
            <td>92.17%</td>
            <td>Nutan Mahavidyalay Selu</td>
            <td>2021</td>
          </tr>
          <tr>
            <td>SSC (Semi English)</td>
            <td>88.60%</td>
            <td>Swami Vivekanand Vidyalay, Mantha</td>
            <td>2019</td>
          </tr>
        </tbody>
      </table>
    </section>
  );
};

export default About;
