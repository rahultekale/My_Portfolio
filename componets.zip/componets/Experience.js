// src/components/Experience.js
import React from 'react';
import './Experience.css'; // Create this CSS file for styling

const Experience = () => {
  const internships = [
    
    {
      title: 'Front-End Web Development Intern',
      company: 'Vexacore Private ltd Services & Solutions',
      Duration:'6 Month',
      description: 'Assisted in building responsive websites and web applications.Work On Html, css , Javascript, react and node js ,etc',
      certificateLink: 'https://drive.google.com/file/d/1_M2-DvvL_XAKeMmNHycTOi-9Xfog03Vl/view', // Replace with your actual link
    },
    {
      title: 'Full Stack Developer Intern',
      company: 'InterForte Company',
      Duration:'6 Month',
      description: 'Worked as an full stack  Devolper.It is training of 5 to 6 month which was realy helpful for me.work on Django , python,etc.',
      certificateLink: 'https://drive.google.com/file/d/1K1cozsm7RxjVlL5nCtZWVkk2f1CHj_lH/view', // Replace with your actual link
    },
    {
      title: 'Java Full Stack Course',
      company: 'Udemy',
      Duration:'6 Month',
      description: 'leran java From Basic to Advance and Contributed to software development projects using Java and Spring Boot.',
      certificateLink: 'https://example.com/certificate3', // Replace with your actual link
    },
    {
        title: 'Java Full Stack Web Devolopmet Training BootCamp',
        company: 'Udemy',
        Duration:'6 Month',
        description: 'leran java From Basic to Advance and Contributed to software development projects using Java and Spring Boot.',
        certificateLink: 'https://example.com/certificate3', // Replace with your actual link
      },
    // Add more internships as needed
  ];

  return (
    <section className="experience-section">
      <h2>My Experience & Courses</h2>
      <div className="experience-list">
        {internships.map((internship, index) => (
          <div className="experience-item" key={index}>
            <h3>{internship.title} at {internship.company} </h3>
            <h4>{internship.Duration}</h4>
            <p>{internship.description}</p>
            <a href={internship.certificateLink} target="_blank" rel="noopener noreferrer" className="certificate-link">View Certificate</a>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Experience;
